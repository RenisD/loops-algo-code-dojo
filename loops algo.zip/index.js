// print odds 1-20

for (var i=1;i<21;i++) {
    if(i % 2 == 1){
        console.log(i);
    }
}
// printohen 1, 3, 5, 7, 9, 11, 13, 15, 17, 19

