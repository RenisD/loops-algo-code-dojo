//ushtrimi 2 (Assigment number 2)

//num and sum 1   5
var sum = 0;
for(var i=1; i<6;i++){
sum +=i;
console.log("Num: " + i + ", Sum: " + sum);

}